CREATE TABLE Customer (
  customerId   CHAR(8) PRIMARY KEY,
  name         VARCHAR(45),
  billAddress  VARCHAR(45),
  collectionId CHAR(8)
);

