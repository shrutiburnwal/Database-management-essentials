CREATE TABLE WorkOrder (
  orderId     CHAR(8) PRIMARY KEY,
  createDate  DATE,
  complDate   DATE,
  workAddress VARCHAR(45),
  customerId  CHAR(8) NOT NULL,
  colTaskId   CHAR(8) NOT NULL,
  FOREIGN KEY (customerId) REFERENCES Customer (customerId)


);
