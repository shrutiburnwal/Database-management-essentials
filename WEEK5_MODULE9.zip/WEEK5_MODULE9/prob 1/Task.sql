CREATE TABLE Task (
  taskId   CHAR(8) PRIMARY KEY,
  name     VARCHAR(45),
  rate     INT,
  estHours INT
);