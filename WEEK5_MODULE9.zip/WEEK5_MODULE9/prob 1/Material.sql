CREATE TABLE Material (
  mtId CHAR(8) PRIMARY KEY,
  name VARCHAR(45),
  cost INT
);