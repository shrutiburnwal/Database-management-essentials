CREATE TABLE WorkTasksCollection (

  wtId           CHAR(8) PRIMARY KEY,
  orderId        CHAR(8) NOT NULL,
  taskId         CHAR(8) NOT NULL,
  status         CHECK (status IN('not started', 'in progress', 'completed')),
  actualHours    INT,
  completionDate DATE,

  FOREIGN KEY (orderId) REFERENCES WorkOrder (orderId),
  FOREIGN KEY (taskId) REFERENCES Task (taskId)

);