
CREATE TABLE LabTest (
  testId   CHAR(8) PRIMARY KEY,
  clientId CHAR(8),
  typeId   CHAR(8),
  seanse   DATE,
  labEmp   CHAR(8),
  CONSTRAINT FK_LabTest FOREIGN KEY (clientId) REFERENCES Client (clientId)
);

