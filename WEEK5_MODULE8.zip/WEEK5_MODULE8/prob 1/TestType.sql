
CREATE TABLE TestType (
  typeId CHAR(8) PRIMARY KEY,
  tName  VARCHAR2(45),
  cost   INT,
  code   INT
);
