
CREATE TABLE Client (
  clientId    CHAR(8) PRIMARY KEY,
  name        VARCHAR2(45) NOT NULL,
  insProvider VARCHAR2(45),
  birthday    DATE,
  address     VARCHAR(45),
  gender VARCHAR(6) NOT NULL CHECK (gender IN ('Male', 'Female'))

);
