
CREATE TABLE TestTypeItem (
  itemId     CHAR(8) PRIMARY KEY,
  typeId     CHAR(8) NOT NULL,
  name       VARCHAR2(45),
  measure    VARCHAR2(45),
  descripion VARCHAR2(45),
  CONSTRAINT FK_TestTpe FOREIGN KEY (typeId) REFERENCES TestType (typeId)
);
